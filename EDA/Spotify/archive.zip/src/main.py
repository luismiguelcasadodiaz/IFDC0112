import extract_spotify_data as esd

## Top 50: World - Data
esd.extract_data('37i9dQZEVXbMDoHDwVN2tF', 'world')

## Top 50: USA - Data
esd.extract_data('37i9dQZEVXbLRQDuF5jeBp', 'usa')

## Top 50: Spain - Data
esd.extract_data('37i9dQZEVXbNFJfN1Vw8d9', 'spain')

## Top 50: UK - Data
esd.extract_data('37i9dQZEVXbLnolsZ8PSNw', 'uk')

## Top 50: Italy - Data
esd.extract_data('37i9dQZEVXbIQnj7RRhdSX', 'italy')

## Top 50: France - Data
esd.extract_data('37i9dQZEVXbIPWwFssbupI', 'france')

## Top 50: Mexico - Data
esd.extract_data('37i9dQZEVXbO3qyFxbkOE1', 'mexico')

## Top 50: Argentina - Data
esd.extract_data('37i9dQZEVXbMMy2roB9myp', 'argentina')

## Top 50: Japan - Data
esd.extract_data('37i9dQZEVXbKXQ4mDTEBXq', 'japan')

## Top 50: South Korea - Data
esd.extract_data('37i9dQZEVXbNxXF4SkHj9F', 'south-korea')